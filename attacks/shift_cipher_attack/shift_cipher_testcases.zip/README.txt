Shift Cipher Test Cases
========================

testcase1.txt  -> Actual Key: 3
testcase2.txt  -> Actual Key: 3
testcase3.txt  -> Actual Key: 23
testcase4.txt  -> Actual Key: 5
testcase5.txt  -> Actual Key: 23
testcase6.txt  -> Actual Key: 10

Note: testcase files contain ONLY ciphertext.
